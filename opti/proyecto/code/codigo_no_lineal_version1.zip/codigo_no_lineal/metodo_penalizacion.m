function [x] = metodo_penalizacion(f_objetivo, f_eq, f_ineq_up, f_ineq_low, var, ...
    xstart, constraints1, constraints2, epsilon, interval, max_iters,verbose)

    %p = 10000000000000000000;
    p = 10;
    
    % se crea una sola función para la penalización por salir de la
    % igualdad
    
    penalize_eq = 0;
    for i = 1:length(f_eq)
        penalize_eq = penalize_eq +  p.*(f_eq(i).^2);
    end


    % se crea una sola función para penalización por no cumplir con las
    % desigualdades
    penalize_ineq_up = 0;
    
    for i = 1:length(f_ineq_up)
       penalize_ineq_up = penalize_ineq_up + p.*(f_ineq_up(i).^2);     
    end

    penalize_ineq_low = 0;
    
    for i = 1:length(f_ineq_low)
       penalize_ineq_low = penalize_ineq_low + p.*(f_ineq_low(i).^2);     
    end
    
    % q0 es la función que penaliza cuando no se están cumpliendo las
    % desigualdades que acotan superiormente
    q0 = f_objetivo + penalize_eq + penalize_ineq_up + penalize_ineq_low;
    
    % q1 es la función que penaliza cuando no se están cumpliendo las
    % desigualdades que acotan superiormente
    q1 = f_objetivo + penalize_eq + penalize_ineq_up;
    
    % q2 es la función que penaliza cuando no se están cumpliendo las
    % desigualdades que acotan inferiormente
    q2 = f_objetivo + penalize_eq + penalize_ineq_low;
    
    % q3 es la función que busca maximizar la funcion objetivo, cumpliendo
    % las restricciones de igualdad, cuando ya se han cumplido las de
    % desigualdad
    
    q3 = f_objetivo + penalize_eq;
    
    x =  gradientDescent(var, q0, q1, q2, q3, constraints1, constraints2, xstart, epsilon, interval, max_iters, verbose);
    x = double(x);


end
